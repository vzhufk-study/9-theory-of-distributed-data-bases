# frozen_string_literal: true

module Lab2
  VERSION = "0.1.0"
end
