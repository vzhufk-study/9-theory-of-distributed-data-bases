class InputReader
  def read(welcome_message: nil, process: nil, validator: nil, error_message: nil)
  
  end
end